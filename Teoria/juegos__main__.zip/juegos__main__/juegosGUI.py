import PySimpleGUI as sg
import hangman
import reversegam
import tictactoeModificado


def main(args):
	
	layout = [[sg.Text('Elegi el juego')], 
		  [sg.Listbox(values=('Ahorcado', 'TA-TE-TI', 'Otello'), background_color='yellow', size=(20,4))],     
		  [sg.OK()]] 
	evento, opcion = sg.Window('Juegos').Layout(layout).Read()  
		
	print(opcion[0][0])
		
	if opcion[0][0] == "Ahorcado":
		hangman.main()
	elif opcion[0][0] == 'TA-TE-TI':
		tictactoeModificado.main()
	elif opcion[0][0] == 'Otello':
		reversegam.main()

		
if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
