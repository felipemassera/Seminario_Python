import streamlit as st
import matplotlib.pyplot as plt
from modulo import funcion
st.title("")
tab1, tab2 = st.tabs(["Tipo Imagen", "Tamaño Imagen"])
with tab1:
    st.subheader("Gráfico de torta que muestre los porcentajes según el tipo de imagen")
    figura = modulo.funcion()
    st.pytplot(figura)
    st.write("Explicación")
