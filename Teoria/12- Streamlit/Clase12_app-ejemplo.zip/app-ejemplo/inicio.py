import streamlit as st
import matplotlib.pyplot as plt
st.title("Estadísticas realizadas por el grupo xx")
st.write("Se utilizaron las librerías")
